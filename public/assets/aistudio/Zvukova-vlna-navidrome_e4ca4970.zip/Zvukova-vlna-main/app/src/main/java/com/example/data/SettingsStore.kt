package com.example.data

import android.content.Context

/**
 * Saved server login. The password itself is never stored: Subsonic authentication only needs
 * the token = md5(password + salt) together with the salt, which is what we keep.
 */
data class SavedCredentials(
    val url: String,
    val username: String,
    val token: String,
    val salt: String
)

/** Small SharedPreferences wrapper (excluded from cloud backup, see res/xml/*_rules.xml). */
class SettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("soundwave_prefs", Context.MODE_PRIVATE)

    fun loadCredentials(): SavedCredentials? {
        val url = prefs.getString(KEY_URL, null)
        val user = prefs.getString(KEY_USER, null)
        val token = prefs.getString(KEY_TOKEN, null)
        val salt = prefs.getString(KEY_SALT, null)
        if (url.isNullOrBlank() || user.isNullOrBlank() || token.isNullOrBlank() || salt.isNullOrBlank()) {
            return null
        }
        return SavedCredentials(url, user, token, salt)
    }

    fun saveCredentials(credentials: SavedCredentials) {
        prefs.edit()
            .putString(KEY_URL, credentials.url)
            .putString(KEY_USER, credentials.username)
            .putString(KEY_TOKEN, credentials.token)
            .putString(KEY_SALT, credentials.salt)
            .apply()
    }

    fun clearCredentials() {
        prefs.edit()
            .remove(KEY_TOKEN)
            .remove(KEY_SALT)
            .apply()
    }

    /** Last typed server URL / user name, so the login form is pre-filled. */
    fun lastServerUrl(): String = prefs.getString(KEY_URL, "") ?: ""

    fun lastUsername(): String = prefs.getString(KEY_USER, "") ?: ""

    fun getString(key: String, default: String): String = prefs.getString(key, default) ?: default

    fun putString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    fun getBoolean(key: String, default: Boolean): Boolean = prefs.getBoolean(key, default)

    fun putBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    companion object {
        private const val KEY_URL = "server_url"
        private const val KEY_USER = "username"
        private const val KEY_TOKEN = "token"
        private const val KEY_SALT = "salt"

        const val KEY_CELLULAR_TRANSCODING = "cellular_transcoding"
        const val KEY_OPUS_BITRATE = "opus_bitrate"
        const val KEY_BACKEND_CODEC = "backend_codec"
        const val KEY_LOGIN_TRANSCODE = "login_transcode_option"
    }
}
